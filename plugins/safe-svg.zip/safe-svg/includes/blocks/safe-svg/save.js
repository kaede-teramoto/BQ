/**
 * @return string Dynamic SVG icon block HTML.
 */
const SafeSVGBlockSave = () => null;

export default SafeSVGBlockSave;
