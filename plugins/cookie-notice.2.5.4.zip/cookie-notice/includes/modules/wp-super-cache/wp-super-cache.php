<?php
// exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
	exit;

/**
 * Cookie Notice Modules WP Super Cache class.
 *
 * Compatibility since: 1.6.9
 *
 * @class Cookie_Notice_Modules_WPSuperCache
 */
class Cookie_Notice_Modules_WPSuperCache {

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		
	}
}

new Cookie_Notice_Modules_WPSuperCache();